# Afk Bot
just copy the code and use a online 24/7 code hosting site.
</p>


## credits
https://github.com/PrismarineJS/mineflayer
https://lunes.host/


